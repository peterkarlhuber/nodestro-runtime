--
-- PostgreSQL database dump
--

\restrict fPKxDpK1wgohtfc28nVWtrRLrw6P4vZlhB5MQkGNu8kp9UdPBDzQQYhCDfI5hjy

-- Dumped from database version 17.11 (Debian 17.11-1.pgdg12+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: nodestro_created_order(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.nodestro_created_order(value text) RETURNS timestamp with time zone
    LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE
    SET "TimeZone" TO 'UTC'
    SET "DateStyle" TO 'ISO, YMD'
    SET search_path TO 'pg_catalog'
    AS $$
BEGIN
    IF value IS NULL OR value !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}' THEN
        RETURN NULL;
    END IF;
    RETURN value::timestamptz;
EXCEPTION WHEN others THEN
    RETURN NULL;
END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: nodestro_axentra_ids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_axentra_ids (
    kind text NOT NULL,
    nodestro_id text NOT NULL COLLATE pg_catalog."C",
    axentra_id text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT nodestro_axentra_ids_axentra_id_check CHECK ((axentra_id <> ''::text)),
    CONSTRAINT nodestro_axentra_ids_kind_check CHECK ((kind = ANY (ARRAY['tenant'::text, 'user'::text, 'session'::text, 'api_key'::text]))),
    CONSTRAINT nodestro_axentra_ids_nodestro_id_check CHECK ((nodestro_id <> ''::text))
);


--
-- Name: nodestro_bootstrap_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_bootstrap_tokens (
    token_hash bytea NOT NULL,
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    used_by text COLLATE pg_catalog."C"
);


--
-- Name: nodestro_chunk_vectors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_chunk_vectors (
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    namespace text NOT NULL COLLATE pg_catalog."C",
    space text NOT NULL COLLATE pg_catalog."C",
    chunk_id bigint NOT NULL,
    embedding real[] NOT NULL,
    CONSTRAINT nodestro_chunk_vectors_tenant_id_check CHECK ((tenant_id <> ''::text))
);


--
-- Name: nodestro_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_chunks (
    id bigint NOT NULL,
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    namespace text NOT NULL COLLATE pg_catalog."C",
    source text NOT NULL COLLATE pg_catalog."C",
    title text,
    file_id text COLLATE pg_catalog."C",
    metadata jsonb NOT NULL,
    text text NOT NULL,
    search_text text NOT NULL,
    search tsvector GENERATED ALWAYS AS (to_tsvector('simple'::regconfig, search_text)) STORED,
    CONSTRAINT nodestro_chunks_tenant_id_check CHECK ((tenant_id <> ''::text))
);


--
-- Name: nodestro_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.nodestro_chunks ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.nodestro_chunks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: nodestro_documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_documents (
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    collection text NOT NULL COLLATE pg_catalog."C",
    id text NOT NULL COLLATE pg_catalog."C",
    data jsonb NOT NULL,
    raw text,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT nodestro_documents_tenant_id_check CHECK ((tenant_id <> ''::text))
);


--
-- Name: nodestro_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_files (
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    namespace text NOT NULL COLLATE pg_catalog."C",
    id text NOT NULL COLLATE pg_catalog."C",
    entry jsonb NOT NULL,
    data bytea NOT NULL,
    CONSTRAINT nodestro_files_tenant_id_check CHECK ((tenant_id <> ''::text))
);


--
-- Name: nodestro_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_jobs (
    id bigint NOT NULL,
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    kind text NOT NULL COLLATE pg_catalog."C",
    ref text NOT NULL COLLATE pg_catalog."C",
    status text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    worker text,
    lease_until timestamp with time zone,
    cancel_requested boolean DEFAULT false NOT NULL,
    error text,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    CONSTRAINT nodestro_jobs_check CHECK (((tenant_id <> ''::text) AND (kind <> ''::text) AND (ref <> ''::text))),
    CONSTRAINT nodestro_jobs_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'running'::text, 'done'::text, 'failed'::text, 'cancelled'::text, 'interrupted'::text])))
);


--
-- Name: nodestro_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.nodestro_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: nodestro_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.nodestro_jobs_id_seq OWNED BY public.nodestro_jobs.id;


--
-- Name: nodestro_login_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_login_states (
    state_hash bytea NOT NULL,
    nonce text NOT NULL,
    code_verifier text NOT NULL,
    return_to text NOT NULL,
    tenant_id text COLLATE pg_catalog."C",
    bootstrap_hash bytea,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: nodestro_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_memberships (
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    user_id text NOT NULL COLLATE pg_catalog."C",
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT nodestro_memberships_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'admin'::text, 'editor'::text, 'operator'::text, 'viewer'::text])))
);


--
-- Name: nodestro_memory_files; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_memory_files (
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    namespace text NOT NULL COLLATE pg_catalog."C",
    path text NOT NULL COLLATE pg_catalog."C",
    content text NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT nodestro_memory_files_tenant_id_check CHECK ((tenant_id <> ''::text))
);


--
-- Name: nodestro_run_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_run_events (
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    run_id text NOT NULL COLLATE pg_catalog."C",
    seq bigint NOT NULL,
    event text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: nodestro_schedule_firings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_schedule_firings (
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    schedule_id text NOT NULL COLLATE pg_catalog."C",
    slot timestamp with time zone NOT NULL,
    run_id text COLLATE pg_catalog."C",
    fired_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: nodestro_schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_schema_migrations (
    version integer NOT NULL,
    name text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    checksum text
);


--
-- Name: nodestro_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_sessions (
    token_hash bytea NOT NULL,
    user_id text NOT NULL COLLATE pg_catalog."C",
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: nodestro_tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_tenants (
    id text NOT NULL COLLATE pg_catalog."C",
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    CONSTRAINT nodestro_tenants_id_check CHECK ((id <> ''::text)),
    CONSTRAINT nodestro_tenants_status_check CHECK ((status = ANY (ARRAY['active'::text, 'suspended'::text])))
);


--
-- Name: nodestro_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_users (
    id text NOT NULL COLLATE pg_catalog."C",
    issuer text NOT NULL COLLATE pg_catalog."C",
    subject text NOT NULL COLLATE pg_catalog."C",
    email text,
    name text,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    last_login_at timestamp with time zone
);


--
-- Name: nodestro_vector_spaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nodestro_vector_spaces (
    tenant_id text NOT NULL COLLATE pg_catalog."C",
    namespace text NOT NULL COLLATE pg_catalog."C",
    space text NOT NULL COLLATE pg_catalog."C",
    identity jsonb NOT NULL,
    dimensions integer NOT NULL,
    state text NOT NULL COLLATE pg_catalog."C",
    CONSTRAINT nodestro_vector_spaces_dimensions_check CHECK ((dimensions > 0)),
    CONSTRAINT nodestro_vector_spaces_state_check CHECK ((state = ANY (ARRAY['active'::text, 'building'::text]))),
    CONSTRAINT nodestro_vector_spaces_tenant_id_check CHECK ((tenant_id <> ''::text))
);


--
-- Name: nodestro_jobs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_jobs ALTER COLUMN id SET DEFAULT nextval('public.nodestro_jobs_id_seq'::regclass);


--
-- Data for Name: nodestro_axentra_ids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_axentra_ids (kind, nodestro_id, axentra_id, created_at) FROM stdin;
\.


--
-- Data for Name: nodestro_bootstrap_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_bootstrap_tokens (token_hash, tenant_id, created_at, expires_at, used_at, used_by) FROM stdin;
\.


--
-- Data for Name: nodestro_chunk_vectors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_chunk_vectors (tenant_id, namespace, space, chunk_id, embedding) FROM stdin;
tenant-a	nodestro	nodestro:529c5ff053902334fe86	1	{-0.7255,0.1451,0.7961,0.1843,0.4039,-0.4039,-0.3176,0.0588}
tenant-a	nodestro	nodestro:529c5ff053902334fe86	2	{0.8431,0.7647,-0.5059,-0.1843,0.9922,0.5529,0.1922,0.8431}
tenant-a	nodestro	nodestro:529c5ff053902334fe86	3	{-0.6471,-0.1765,-0.0275,-0.9294,-0.5137,-0.1451,-0.9529,0.2392}
tenant-a	nodestro	nodestro:529c5ff053902334fe86	4	{0.1529,-0.6863,0.4745,-0.1059,0.6078,0.1608,0.0353,0.5922}
tenant-a	nodestro	nodestro:529c5ff053902334fe86	5	{0.4824,0.9294,0.5843,0.302,-0.851,0.3412,-0.749,0.6941}
tenant-a	nodestro	nodestro:11caa1e04fef0be43ba2	1	{-0.9922,-0.5843,-0.2392,-0.3412,-0.3255,0.8431}
tenant-a	nodestro	nodestro:11caa1e04fef0be43ba2	2	{0.1137,-0.7961,0.9765,-0.1373,0.5922,-0.6471}
tenant-a	nodestro	nodestro:529c5ff053902334fe86	6	{0,0,0,0,0,0,0,0}
tenant-b	nodestro	nodestro:529c5ff053902334fe86	7	{-0.7255,0.1451,0.7961,0.1843,0.4039,-0.4039,-0.3176,0.0588}
tenant-b	nodestro	nodestro:529c5ff053902334fe86	8	{0.8431,0.7647,-0.5059,-0.1843,0.9922,0.5529,0.1922,0.8431}
tenant-b	nodestro	nodestro:529c5ff053902334fe86	9	{-0.6471,-0.1765,-0.0275,-0.9294,-0.5137,-0.1451,-0.9529,0.2392}
tenant-b	nodestro	nodestro:529c5ff053902334fe86	10	{-0.2863,-0.4902,0.498,0.7961,-0.851,-0.2392,0.702,0.8431}
tenant-b	nodestro	nodestro:529c5ff053902334fe86	11	{0.4824,0.9294,0.5843,0.302,-0.851,0.3412,-0.749,0.6941}
tenant-b	nodestro	nodestro:11caa1e04fef0be43ba2	7	{-0.9922,-0.5843,-0.2392,-0.3412,-0.3255,0.8431}
tenant-b	nodestro	nodestro:11caa1e04fef0be43ba2	8	{0.1137,-0.7961,0.9765,-0.1373,0.5922,-0.6471}
tenant-b	nodestro	nodestro:529c5ff053902334fe86	12	{0,0,0,0,0,0,0,0}
\.


--
-- Data for Name: nodestro_chunks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_chunks (id, tenant_id, namespace, source, title, file_id, metadata, text, search_text) FROM stdin;
1	tenant-a	nodestro	e711c086008e70cc	handbook.md	e711c086008e70cc	{}	# Fixture handbook\n\nThe blue heron nests near the river. Orders ship within two days.\n\n## Returns\n\nA return label is valid for thirty days. Refunds go to the original payment method.	fixture handbook the blue heron nests near the river orders ship within two days returns a return label is valid for thirty days refunds go to the original payment method handbook md
2	tenant-a	nodestro	5b462c64a0a98e6d	glossary.txt	5b462c64a0a98e6d	{}	Alpha means the first release. Beta means the second release. Gamma is the third.	alpha means the first release beta means the second release gamma is the third glossary txt
3	tenant-a	nodestro	243831c0c41cc726	faq.md	243831c0c41cc726	{}	# FAQ\n\nHow long is shipping? Two days.\n\nWho answers support mail? The fixture team.	faq how long is shipping two days who answers support mail the fixture team faq md
4	tenant-a	nodestro	c4cf43408edede4a	marker-a.txt	c4cf43408edede4a	{}	Marker of tenant-a: aardvark amethyst.	marker of tenant a aardvark amethyst marker a txt
5	tenant-a	nodestro	134bd2a46df861f5	late-note.txt	134bd2a46df861f5	{}	A late note about the heron and the river, indexed with vectors on upload.	a late note about the heron and the river indexed with vectors on upload late note txt
6	tenant-a	nodestro	eed3e85b0d7ab403	zero-vector.txt	eed3e85b0d7ab403	{}	This chunk carries a zero vector written by SQL.	this chunk carries a zero vector written by sql zero vector txt
7	tenant-b	nodestro	e711c086008e70cc	handbook.md	e711c086008e70cc	{}	# Fixture handbook\n\nThe blue heron nests near the river. Orders ship within two days.\n\n## Returns\n\nA return label is valid for thirty days. Refunds go to the original payment method.	fixture handbook the blue heron nests near the river orders ship within two days returns a return label is valid for thirty days refunds go to the original payment method handbook md
8	tenant-b	nodestro	5b462c64a0a98e6d	glossary.txt	5b462c64a0a98e6d	{}	Alpha means the first release. Beta means the second release. Gamma is the third.	alpha means the first release beta means the second release gamma is the third glossary txt
9	tenant-b	nodestro	243831c0c41cc726	faq.md	243831c0c41cc726	{}	# FAQ\n\nHow long is shipping? Two days.\n\nWho answers support mail? The fixture team.	faq how long is shipping two days who answers support mail the fixture team faq md
10	tenant-b	nodestro	a96003cf08231f32	marker-b.txt	a96003cf08231f32	{}	Marker of tenant-b: zebra zircon.	marker of tenant b zebra zircon marker b txt
11	tenant-b	nodestro	134bd2a46df861f5	late-note.txt	134bd2a46df861f5	{}	A late note about the heron and the river, indexed with vectors on upload.	a late note about the heron and the river indexed with vectors on upload late note txt
12	tenant-b	nodestro	eed3e85b0d7ab403	zero-vector.txt	eed3e85b0d7ab403	{}	This chunk carries a zero vector written by SQL.	this chunk carries a zero vector written by sql zero vector txt
\.


--
-- Data for Name: nodestro_documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_documents (tenant_id, collection, id, data, raw, updated_at) FROM stdin;
\.


--
-- Data for Name: nodestro_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_files (tenant_id, namespace, id, entry, data) FROM stdin;
tenant-a	nodestro	e711c086008e70cc	{"id": "e711c086008e70cc", "name": "handbook.md", "size": 183, "sha256": "e711c086008e70cc46f983437eb1ee223fc7b6bf72c2ec729a035f8dbf62ba53", "metadata": {"collection": "fixture"}, "created_at": "2026-11-06T22:13:25.840050Z", "media_type": "text/markdown", "api_file_id": null, "description": "fixture file handbook.md"}	\\x2320466978747572652068616e64626f6f6b0a0a54686520626c7565206865726f6e206e65737473206e656172207468652072697665722e204f726465727320736869702077697468696e2074776f20646179732e0a0a23232052657475726e730a0a412072657475726e206c6162656c2069732076616c696420666f722074686972747920646179732e20526566756e647320676f20746f20746865206f726967696e616c207061796d656e74206d6574686f642e0a
tenant-a	nodestro	5b462c64a0a98e6d	{"id": "5b462c64a0a98e6d", "name": "glossary.txt", "size": 82, "sha256": "5b462c64a0a98e6d018b5e3e747147bae98418a33eaa64ef2dad8d2f4e0c596f", "metadata": {"collection": "fixture"}, "created_at": "2026-11-06T22:13:25.847327Z", "media_type": "text/plain", "api_file_id": null, "description": "fixture file glossary.txt"}	\\x416c706861206d65616e73207468652066697273742072656c656173652e2042657461206d65616e7320746865207365636f6e642072656c656173652e2047616d6d61206973207468652074686972642e0a
tenant-a	nodestro	243831c0c41cc726	{"id": "243831c0c41cc726", "name": "faq.md", "size": 84, "sha256": "243831c0c41cc726f47b88c916e7ff88eb6a6bf2c43d66b0c70f2eaeea485e70", "metadata": {"collection": "fixture"}, "created_at": "2026-11-06T22:13:25.853149Z", "media_type": "text/markdown", "api_file_id": null, "description": "fixture file faq.md"}	\\x23204641510a0a486f77206c6f6e67206973207368697070696e673f2054776f20646179732e0a0a57686f20616e737765727320737570706f7274206d61696c3f205468652066697874757265207465616d2e0a
tenant-a	nodestro	c4cf43408edede4a	{"id": "c4cf43408edede4a", "name": "marker-a.txt", "size": 39, "sha256": "c4cf43408edede4a465221dea2c7ee5fc39b63456cbc290b72d9bb0377e48d2a", "metadata": {}, "created_at": "2026-11-06T22:13:25.862627Z", "media_type": "text/plain", "api_file_id": null, "description": "tenant marker"}	\\x4d61726b6572206f662074656e616e742d613a20616172647661726b20616d6574687973742e0a
tenant-a	nodestro	134bd2a46df861f5	{"id": "134bd2a46df861f5", "name": "late-note.txt", "size": 75, "sha256": "134bd2a46df861f5540186c6911a950a28d3eb19c57207614f24855cd8a40902", "metadata": {}, "created_at": "2026-11-06T22:13:25.888869Z", "media_type": "text/plain", "api_file_id": null, "description": "added with vectors"}	\\x41206c617465206e6f74652061626f757420746865206865726f6e20616e64207468652072697665722c20696e6465786564207769746820766563746f7273206f6e2075706c6f61642e0a
tenant-a	nodestro	eed3e85b0d7ab403	{"id": "eed3e85b0d7ab403", "name": "zero-vector.txt", "size": 49, "sha256": "eed3e85b0d7ab403a405cd99a6813869a1e07b94b7fd2ae2dc6aa72eddb5a42e", "metadata": {}, "created_at": "2026-11-06T22:13:25.897344Z", "media_type": "text/plain", "api_file_id": null, "description": "added with vectors"}	\\x54686973206368756e6b20636172726965732061207a65726f20766563746f72207772697474656e2062792053514c2e0a
tenant-b	nodestro	e711c086008e70cc	{"id": "e711c086008e70cc", "name": "handbook.md", "size": 183, "sha256": "e711c086008e70cc46f983437eb1ee223fc7b6bf72c2ec729a035f8dbf62ba53", "metadata": {"collection": "fixture"}, "created_at": "2026-11-06T22:13:25.937829Z", "media_type": "text/markdown", "api_file_id": null, "description": "fixture file handbook.md"}	\\x2320466978747572652068616e64626f6f6b0a0a54686520626c7565206865726f6e206e65737473206e656172207468652072697665722e204f726465727320736869702077697468696e2074776f20646179732e0a0a23232052657475726e730a0a412072657475726e206c6162656c2069732076616c696420666f722074686972747920646179732e20526566756e647320676f20746f20746865206f726967696e616c207061796d656e74206d6574686f642e0a
tenant-b	nodestro	5b462c64a0a98e6d	{"id": "5b462c64a0a98e6d", "name": "glossary.txt", "size": 82, "sha256": "5b462c64a0a98e6d018b5e3e747147bae98418a33eaa64ef2dad8d2f4e0c596f", "metadata": {"collection": "fixture"}, "created_at": "2026-11-06T22:13:25.941148Z", "media_type": "text/plain", "api_file_id": null, "description": "fixture file glossary.txt"}	\\x416c706861206d65616e73207468652066697273742072656c656173652e2042657461206d65616e7320746865207365636f6e642072656c656173652e2047616d6d61206973207468652074686972642e0a
tenant-b	nodestro	243831c0c41cc726	{"id": "243831c0c41cc726", "name": "faq.md", "size": 84, "sha256": "243831c0c41cc726f47b88c916e7ff88eb6a6bf2c43d66b0c70f2eaeea485e70", "metadata": {"collection": "fixture"}, "created_at": "2026-11-06T22:13:25.944375Z", "media_type": "text/markdown", "api_file_id": null, "description": "fixture file faq.md"}	\\x23204641510a0a486f77206c6f6e67206973207368697070696e673f2054776f20646179732e0a0a57686f20616e737765727320737570706f7274206d61696c3f205468652066697874757265207465616d2e0a
tenant-b	nodestro	a96003cf08231f32	{"id": "a96003cf08231f32", "name": "marker-b.txt", "size": 34, "sha256": "a96003cf08231f3281db4823a313f6ef7cdf56bdccc1de138401d00f722091f1", "metadata": {}, "created_at": "2026-11-06T22:13:25.947981Z", "media_type": "text/plain", "api_file_id": null, "description": "tenant marker"}	\\x4d61726b6572206f662074656e616e742d623a207a65627261207a6972636f6e2e0a
tenant-b	nodestro	134bd2a46df861f5	{"id": "134bd2a46df861f5", "name": "late-note.txt", "size": 75, "sha256": "134bd2a46df861f5540186c6911a950a28d3eb19c57207614f24855cd8a40902", "metadata": {}, "created_at": "2026-11-06T22:13:25.969821Z", "media_type": "text/plain", "api_file_id": null, "description": "added with vectors"}	\\x41206c617465206e6f74652061626f757420746865206865726f6e20616e64207468652072697665722c20696e6465786564207769746820766563746f7273206f6e2075706c6f61642e0a
tenant-b	nodestro	eed3e85b0d7ab403	{"id": "eed3e85b0d7ab403", "name": "zero-vector.txt", "size": 49, "sha256": "eed3e85b0d7ab403a405cd99a6813869a1e07b94b7fd2ae2dc6aa72eddb5a42e", "metadata": {}, "created_at": "2026-11-06T22:13:25.984301Z", "media_type": "text/plain", "api_file_id": null, "description": "added with vectors"}	\\x54686973206368756e6b20636172726965732061207a65726f20766563746f72207772697474656e2062792053514c2e0a
\.


--
-- Data for Name: nodestro_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_jobs (id, tenant_id, kind, ref, status, payload, attempts, worker, lease_until, cancel_requested, error, created_at, started_at, finished_at) FROM stdin;
\.


--
-- Data for Name: nodestro_login_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_login_states (state_hash, nonce, code_verifier, return_to, tenant_id, bootstrap_hash, expires_at) FROM stdin;
\.


--
-- Data for Name: nodestro_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_memberships (tenant_id, user_id, role, created_at) FROM stdin;
\.


--
-- Data for Name: nodestro_memory_files; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_memory_files (tenant_id, namespace, path, content, updated_at) FROM stdin;
tenant-a	nodestro:fixture-notes	notes.md	Shared fixture note.\nThe heron is blue.\n	2026-11-06 22:13:25.934075+00
tenant-a	nodestro:fixture-notes	projects/plan.md	Plan of the fixture project.\n	2026-11-06 22:13:25.935835+00
tenant-a	nodestro:fixture-notes	tenant-a.md	Only tenant-a has this memory file.\n	2026-11-06 22:13:25.936924+00
tenant-b	nodestro:fixture-notes	notes.md	Shared fixture note.\nThe heron is blue.\n	2026-11-06 22:13:26.019441+00
tenant-b	nodestro:fixture-notes	projects/plan.md	Plan of the fixture project.\n	2026-11-06 22:13:26.023048+00
tenant-b	nodestro:fixture-notes	tenant-b.md	Only tenant-b has this memory file.\n	2026-11-06 22:13:26.027297+00
\.


--
-- Data for Name: nodestro_run_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_run_events (tenant_id, run_id, seq, event, created_at) FROM stdin;
\.


--
-- Data for Name: nodestro_schedule_firings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_schedule_firings (tenant_id, schedule_id, slot, run_id, fired_at) FROM stdin;
\.


--
-- Data for Name: nodestro_schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_schema_migrations (version, name, applied_at, checksum) FROM stdin;
1	0001_documents.sql	2026-11-06 22:13:25.739102+00	aa3bf7c5b3a8cd52a59f5b09b15b47746263d977a2716038a42421b7c29d5f18
2	0002_knowledge_memory.sql	2026-11-06 22:13:25.739102+00	2838b1ea2b91bf1d460e22e2c1373d2a73078dda79fc41f68b62fd941ad03409
3	0003_identity.sql	2026-11-06 22:13:25.739102+00	bfe77a13b03b8823621a5258473d479eecd96e9359a87c52a90790547afb77a7
4	0004_jobs.sql	2026-11-06 22:13:25.739102+00	6bc223ed073628a2198a278f0a04150b5560795de3a95d49955c569824dccba7
5	0005_find_indexes.sql	2026-11-06 22:13:25.739102+00	ad75b8be04d242e435ea689cd0c58265e01f11a0a183b27c41fa6a43c343200b
6	0006_partial_find_indexes.sql	2026-11-06 22:13:25.739102+00	f5481069398d91860897e1e164276217be2d91cdff75c2c1c8f364216743f592
7	0007_axentra_links.sql	2026-11-06 22:13:25.739102+00	5cdbd4f63be6813a0ccd25c469e865aaaf3f73f5b5bece23402051fb6758b97e
8	0008_tenant_status.sql	2026-11-06 22:13:25.739102+00	afd8f83c39c8d82e1b91b099e5d737843008ecd1055077b580c921a46f53b3a8
9	0009_created_order.sql	2026-11-06 22:13:25.739102+00	bada36a3af623fb6b4a08e317c3e92cc4b275d8c56db6710c9bf6f2d4661e8ba
10	0010_knowledge_vectors.sql	2026-11-06 22:13:25.739102+00	aadda58e1c14e6654bca42394e058ae85ad44309b2f017d9ec2f15409a6732f5
\.


--
-- Data for Name: nodestro_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_sessions (token_hash, user_id, tenant_id, created_at, last_seen_at, expires_at) FROM stdin;
\.


--
-- Data for Name: nodestro_tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_tenants (id, name, created_at, status) FROM stdin;
\.


--
-- Data for Name: nodestro_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_users (id, issuer, subject, email, name, created_at, last_login_at) FROM stdin;
\.


--
-- Data for Name: nodestro_vector_spaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nodestro_vector_spaces (tenant_id, namespace, space, identity, dimensions, state) FROM stdin;
tenant-a	nodestro	nodestro:529c5ff053902334fe86	{"model": "fx-embed-a", "digest": "", "provider": "fixture", "dimensions": 8, "normalized": false, "query_prefix": "", "document_prefix": "", "query_instruction": "", "document_instruction": ""}	8	active
tenant-a	nodestro	nodestro:11caa1e04fef0be43ba2	{"model": "fx-embed-b", "digest": "", "provider": "fixture", "dimensions": 6, "normalized": false, "query_prefix": "", "document_prefix": "", "query_instruction": "", "document_instruction": ""}	6	building
tenant-b	nodestro	nodestro:529c5ff053902334fe86	{"model": "fx-embed-a", "digest": "", "provider": "fixture", "dimensions": 8, "normalized": false, "query_prefix": "", "document_prefix": "", "query_instruction": "", "document_instruction": ""}	8	active
tenant-b	nodestro	nodestro:11caa1e04fef0be43ba2	{"model": "fx-embed-b", "digest": "", "provider": "fixture", "dimensions": 6, "normalized": false, "query_prefix": "", "document_prefix": "", "query_instruction": "", "document_instruction": ""}	6	building
\.


--
-- Name: nodestro_chunks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nodestro_chunks_id_seq', 12, true);


--
-- Name: nodestro_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.nodestro_jobs_id_seq', 1, false);


--
-- Name: nodestro_axentra_ids nodestro_axentra_ids_kind_axentra_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_axentra_ids
    ADD CONSTRAINT nodestro_axentra_ids_kind_axentra_id_key UNIQUE (kind, axentra_id);


--
-- Name: nodestro_axentra_ids nodestro_axentra_ids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_axentra_ids
    ADD CONSTRAINT nodestro_axentra_ids_pkey PRIMARY KEY (kind, nodestro_id);


--
-- Name: nodestro_bootstrap_tokens nodestro_bootstrap_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_bootstrap_tokens
    ADD CONSTRAINT nodestro_bootstrap_tokens_pkey PRIMARY KEY (token_hash);


--
-- Name: nodestro_chunk_vectors nodestro_chunk_vectors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_chunk_vectors
    ADD CONSTRAINT nodestro_chunk_vectors_pkey PRIMARY KEY (tenant_id, space, chunk_id);


--
-- Name: nodestro_chunks nodestro_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_chunks
    ADD CONSTRAINT nodestro_chunks_pkey PRIMARY KEY (id);


--
-- Name: nodestro_documents nodestro_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_documents
    ADD CONSTRAINT nodestro_documents_pkey PRIMARY KEY (tenant_id, collection, id);


--
-- Name: nodestro_files nodestro_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_files
    ADD CONSTRAINT nodestro_files_pkey PRIMARY KEY (tenant_id, namespace, id);


--
-- Name: nodestro_jobs nodestro_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_jobs
    ADD CONSTRAINT nodestro_jobs_pkey PRIMARY KEY (id);


--
-- Name: nodestro_login_states nodestro_login_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_login_states
    ADD CONSTRAINT nodestro_login_states_pkey PRIMARY KEY (state_hash);


--
-- Name: nodestro_memberships nodestro_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_memberships
    ADD CONSTRAINT nodestro_memberships_pkey PRIMARY KEY (tenant_id, user_id);


--
-- Name: nodestro_memory_files nodestro_memory_files_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_memory_files
    ADD CONSTRAINT nodestro_memory_files_pkey PRIMARY KEY (tenant_id, namespace, path);


--
-- Name: nodestro_run_events nodestro_run_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_run_events
    ADD CONSTRAINT nodestro_run_events_pkey PRIMARY KEY (tenant_id, run_id, seq);


--
-- Name: nodestro_schedule_firings nodestro_schedule_firings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_schedule_firings
    ADD CONSTRAINT nodestro_schedule_firings_pkey PRIMARY KEY (tenant_id, schedule_id, slot);


--
-- Name: nodestro_schema_migrations nodestro_schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_schema_migrations
    ADD CONSTRAINT nodestro_schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: nodestro_sessions nodestro_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_sessions
    ADD CONSTRAINT nodestro_sessions_pkey PRIMARY KEY (token_hash);


--
-- Name: nodestro_tenants nodestro_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_tenants
    ADD CONSTRAINT nodestro_tenants_pkey PRIMARY KEY (id);


--
-- Name: nodestro_users nodestro_users_issuer_subject_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_users
    ADD CONSTRAINT nodestro_users_issuer_subject_key UNIQUE (issuer, subject);


--
-- Name: nodestro_users nodestro_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_users
    ADD CONSTRAINT nodestro_users_pkey PRIMARY KEY (id);


--
-- Name: nodestro_vector_spaces nodestro_vector_spaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_vector_spaces
    ADD CONSTRAINT nodestro_vector_spaces_pkey PRIMARY KEY (tenant_id, namespace, space);


--
-- Name: nodestro_chunk_vectors_chunk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_chunk_vectors_chunk ON public.nodestro_chunk_vectors USING btree (chunk_id);


--
-- Name: nodestro_chunks_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_chunks_search ON public.nodestro_chunks USING gin (search);


--
-- Name: nodestro_chunks_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_chunks_source ON public.nodestro_chunks USING btree (tenant_id, namespace, source);


--
-- Name: nodestro_documents_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_documents_runs_created ON public.nodestro_documents USING btree (tenant_id, collection, public.nodestro_created_order((data ->> 'created_at'::text)) DESC, id DESC) WHERE (collection = 'runs'::text);


--
-- Name: nodestro_documents_runs_created_top; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_documents_runs_created_top ON public.nodestro_documents USING btree (tenant_id, collection, public.nodestro_created_order((data ->> 'created_at'::text)) DESC, id DESC) WHERE ((collection = 'runs'::text) AND ((data ->> 'parent_run_id'::text) IS NULL));


--
-- Name: nodestro_documents_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_documents_status ON public.nodestro_documents USING btree (tenant_id, collection, ((data ->> 'status'::text))) WHERE ((data ->> 'status'::text) IS NOT NULL);


--
-- Name: nodestro_documents_trigger_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_documents_trigger_ref ON public.nodestro_documents USING btree (tenant_id, collection, ((data ->> 'trigger_ref'::text))) WHERE ((data ->> 'trigger_ref'::text) IS NOT NULL);


--
-- Name: nodestro_documents_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_documents_updated ON public.nodestro_documents USING btree (tenant_id, collection, updated_at DESC, id);


--
-- Name: nodestro_jobs_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX nodestro_jobs_active ON public.nodestro_jobs USING btree (tenant_id, kind, ref) WHERE (status = ANY (ARRAY['queued'::text, 'running'::text]));


--
-- Name: nodestro_jobs_leases; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_jobs_leases ON public.nodestro_jobs USING btree (lease_until) WHERE (status = 'running'::text);


--
-- Name: nodestro_jobs_queued; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_jobs_queued ON public.nodestro_jobs USING btree (kind, id) WHERE (status = 'queued'::text);


--
-- Name: nodestro_memberships_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_memberships_user ON public.nodestro_memberships USING btree (user_id);


--
-- Name: nodestro_run_events_age; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_run_events_age ON public.nodestro_run_events USING btree (created_at);


--
-- Name: nodestro_sessions_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_sessions_expiry ON public.nodestro_sessions USING btree (expires_at);


--
-- Name: nodestro_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nodestro_sessions_user ON public.nodestro_sessions USING btree (user_id);


--
-- Name: nodestro_bootstrap_tokens nodestro_bootstrap_tokens_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_bootstrap_tokens
    ADD CONSTRAINT nodestro_bootstrap_tokens_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.nodestro_tenants(id) ON DELETE CASCADE;


--
-- Name: nodestro_bootstrap_tokens nodestro_bootstrap_tokens_used_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_bootstrap_tokens
    ADD CONSTRAINT nodestro_bootstrap_tokens_used_by_fkey FOREIGN KEY (used_by) REFERENCES public.nodestro_users(id) ON DELETE SET NULL;


--
-- Name: nodestro_chunk_vectors nodestro_chunk_vectors_chunk_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_chunk_vectors
    ADD CONSTRAINT nodestro_chunk_vectors_chunk_id_fkey FOREIGN KEY (chunk_id) REFERENCES public.nodestro_chunks(id) ON DELETE CASCADE;


--
-- Name: nodestro_chunk_vectors nodestro_chunk_vectors_tenant_id_namespace_space_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_chunk_vectors
    ADD CONSTRAINT nodestro_chunk_vectors_tenant_id_namespace_space_fkey FOREIGN KEY (tenant_id, namespace, space) REFERENCES public.nodestro_vector_spaces(tenant_id, namespace, space) ON DELETE CASCADE;


--
-- Name: nodestro_memberships nodestro_memberships_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_memberships
    ADD CONSTRAINT nodestro_memberships_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.nodestro_tenants(id) ON DELETE CASCADE;


--
-- Name: nodestro_memberships nodestro_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_memberships
    ADD CONSTRAINT nodestro_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.nodestro_users(id) ON DELETE CASCADE;


--
-- Name: nodestro_sessions nodestro_sessions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_sessions
    ADD CONSTRAINT nodestro_sessions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.nodestro_tenants(id) ON DELETE CASCADE;


--
-- Name: nodestro_sessions nodestro_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nodestro_sessions
    ADD CONSTRAINT nodestro_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.nodestro_users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fPKxDpK1wgohtfc28nVWtrRLrw6P4vZlhB5MQkGNu8kp9UdPBDzQQYhCDfI5hjy

